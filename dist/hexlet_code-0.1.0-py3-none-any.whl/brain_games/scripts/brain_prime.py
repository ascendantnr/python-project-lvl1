#!/usr/bin/env python
from brain_games.motor import motor
from brain_games.games import prime


def main():
    motor(prime)


if __name__ == "__main__":
    main()
